import React from 'react'
import Navbar from '../components/Navbar';
import HeroSection from "../components/HeroSection"
import CardSection from '../components/CardSection';
import AboutUs from '../components/AboutUs';
import Category from '../components/Category';

function Home() {
  return (
    <div>
        <Navbar />
        <HeroSection /> 
        <CardSection />
        <AboutUs />  
        <Category />      
    </div>
  )
}

export default Home