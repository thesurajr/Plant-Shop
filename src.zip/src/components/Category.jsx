import React from "react";
import plant4 from "../assets/plant4.png";
import plant5 from "../assets/plant5.png";
import plant6 from "../assets/plant6.png";

function Category() {
  return (
    <div className="w-full my-20 py-20 bg-red-500 border-4">
      <div className="w-full block text-center ">
        <h1 className="font-bold text-2xl my-16">Categories</h1>
        <p className="text-gray-500">Find what you are looking for</p>
        <div className="w-full flex justify-evenly flex-wrap ">
          <div className="">
            <div className="">
              <img
                className="w-48 h-60 object-fill"
                src={plant4}
                alt="Natural Plants"
              />
            </div>
            <h3>Natural Plants</h3>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Category;
