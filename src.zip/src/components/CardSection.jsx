import React from "react";
import { RiArrowRightLongLine } from "react-icons/ri";
import "../components/CardSection.css";
import plant1 from "../assets/plant1.png";
import plant2 from "../assets/plant2.png";
import plant3 from "../assets/plant3.png";

function CardSection() {
  const plants = [
    {
      id: 1,
      image: plant1,
      title: "Natural Plant",
      price: "₹1,499.00",
    },
    {
      id: 1,
      image: plant2,
      title: "Artificial Plant",
      price: "₹900.00",
    },
    {
      id: 1,
      image: plant3,
      title: "Indoor Plant",
      price: "₹3,500.00",
    },
  ];

  return (
    <section className="card-section">
      <div className="card-text">
        <h3>Best Selling {<br/>} Plants</h3>
        <p>Easiest way to {<br/>}  healthy life by buying  {<br/>} your favorite plants </p>
        <button>
          See more <RiArrowRightLongLine className="btn-arrow" />

        </button>
      </div>
      <div className="card-container">
        {plants.map((item) => (
          <div className="card" key={item.id}>
            <img src={item.image} alt={item.title} className="card-image" />
            <div className="card-content">
              <h3>{item.title}</h3>
              <p>{item.price}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default CardSection;
