import React from "react";
import { Link, NavLink  } from "react-router-dom";
import Greenmind from "../assets/GREENMIND.png";
import { CiShoppingCart, CiUser } from "react-icons/ci";
import { MdOutlineSegment } from "react-icons/md";
import { RxDividerVertical } from "react-icons/rx";
import "../components/Navbar.css";

function Navbar() {
  return (
    <nav>
      <div className="navbar">
        <div className="navbar-container">
          <div className="logo">
            <img src={Greenmind} alt="greenmind logo" />
          </div>
          <div className="navbar-links">
            <NavLink
              to="/"
              className={({ isActive }) => (isActive ? "active-link" : "")}
            >
              Home
            </NavLink>
            <Link to="/products" className="nav-links">
              Products
            </Link>
            <Link to="/contact" className="nav-links">
              Contact
            </Link>
          </div>
        </div>
        <div className="navbar-icons">
          <Link to="/cart" className="shopping-cart"><CiShoppingCart /></Link>
          <Link to="/admin" className="admin"><CiUser /></Link>
            <RxDividerVertical size={30} />
          <Link to="/hamburger/menu" className="hamburger-btn"><MdOutlineSegment /></Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
